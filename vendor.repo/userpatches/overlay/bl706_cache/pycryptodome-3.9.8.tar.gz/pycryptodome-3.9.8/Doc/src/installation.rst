.. include:: ../../INSTALL.rst
